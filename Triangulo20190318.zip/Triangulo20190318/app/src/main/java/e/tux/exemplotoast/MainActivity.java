package e.tux.exemplotoast;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    double x;
    double y;
    double z;
    Button mButton;
    String tipoTriangulo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mButton = findViewById(R.id.btToast);
        mButton.setOnClickListener(this);



    }

    public void onClick(View v){
        int i = v.getId();
        if (i == R.id.btToast){
            compare();
            Toast.makeText(this,tipoTriangulo, 1).show();
        }

    }

    public void compare(){
        TextView campoX = findViewById(R.id.etX);
        TextView campoY = findViewById(R.id.etY);
        TextView campoZ = findViewById(R.id.etZ);
        x = Double.parseDouble(campoX.getText().toString());
        y = Double.parseDouble(campoY.getText().toString());
        z = Double.parseDouble(campoZ.getText().toString());

        if (x<=0 | y<=0 | z<=0 ){
            tipoTriangulo = "Não é um Triângulo";
        } else if (x == y & y == z ){
            tipoTriangulo = "Triângulo Equilátero";
        } else if (x == y | x == z | y == z ){
            tipoTriangulo = "Triângulo Isósceles";
        } else if (x != y & x != z & y != z){
            tipoTriangulo = "Triângulo Escaleno";
        }
    }



}
