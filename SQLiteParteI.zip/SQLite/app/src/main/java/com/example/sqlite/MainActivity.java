package com.example.sqlite;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {

            SQLiteDatabase banco = openOrCreateDatabase("sistema", MODE_PRIVATE, null);

            //criar tabela
            banco.execSQL("CREATE TABLE IF NOT EXISTS usuario " +
                    "(id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "usuario VARCHAR," +
                    "senha INT(8)" +
                    ")"
                );

            /*
            //inserção de dados
            banco.execSQL("INSERT INTO usuario(usuario, senha) " +
                    "VALUES('gilmario', 123)");
            banco.execSQL("INSERT INTO usuario(usuario, senha) " +
                    "VALUES('augusto', 456)");
            banco.execSQL("INSERT INTO usuario(usuario, senha) " +
                    "VALUES('filho', 789)");
            */

            //Alterar Dados
            banco.execSQL("UPDATE usuario SET usuario = 'FLECHA' WHERE id = 1");

            //Deletar Dados
            banco.execSQL("DELETE FROM usuario WHERE id = 2");

            //Retornar e Listar dados do Banco
            Cursor cursor = banco.rawQuery("SELECT * FROM usuario WHERE usuario LIKE '%au%'", null);
            int indiceId = cursor.getColumnIndex("id");
            int indiceUsuario = cursor.getColumnIndex("usuario");
            int indiceSenha = cursor.getColumnIndex("senha");

            //voltar para o primeiro item da lista
            cursor.moveToFirst();

            while(cursor != null){
                Log.i("DADOS USUARIO - id", cursor.getString(indiceId));
                Log.i("DADOS USUARIO - usuario", cursor.getString(indiceUsuario));
                Log.i("DADOS USUARIO - senha", cursor.getString(indiceSenha));

                //Avançar para o proximo indice
                cursor.moveToNext();
            }

        } catch (Exception e){
            e.printStackTrace();
        }

    }
}
