package com.example.mediaplayer;

import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button botaoPlay;
    private Button botaoReset;
    private MediaPlayer media;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        botaoPlay = findViewById(R.id.botao_play);
        botaoReset = findViewById(R.id.botao_reset);
        media = MediaPlayer.create(getApplicationContext(), R.raw.musica);

        botaoPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              if (media.isPlaying()){
                  pauseMusic();
              } else {
                  startMusic();
              }
            }
        });

        botaoReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetMusic();
            }
        });
    }

    public void startMusic(){
        if (media != null){
            media.start();
            botaoPlay.setText("Pause");
        }
    }

    public void pauseMusic(){
        if (media != null){
            media.pause();
            botaoPlay.setText("Play");
        }
    }

    public void resetMusic(){
        if (media != null){
            media.seekTo(0);
            media.pause();
            botaoPlay.setText("Play");
        }
    }

    @Override
    protected void onDestroy(){
        if (media != null){
            media.stop();
            media.release();
            media = null;
        }
        super.onDestroy();
    }
}
