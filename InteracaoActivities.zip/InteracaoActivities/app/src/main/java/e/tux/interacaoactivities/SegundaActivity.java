package e.tux.interacaoactivities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SegundaActivity extends AppCompatActivity {

    TextView texto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda);

        texto = findViewById(R.id.texto);

        String textoCapturado;
        Bundle bundle = getIntent().getExtras();

        if (bundle != null){
            textoCapturado = bundle.getString("nome");
            texto.setText(textoCapturado);
        }
    }
}
